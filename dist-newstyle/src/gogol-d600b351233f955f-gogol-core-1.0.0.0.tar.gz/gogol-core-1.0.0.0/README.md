# Gogol Core

* [Description](#description)
* [Contribute](#contribute)
* [Licence](#licence)


## Description

> TODO


## Contribute

For any problems, comments, or feedback please create an issue [here on GitHub](https://github.com/brendanhay/gogol/issues).


## Licence

Gogol is released under the [Mozilla Public License Version 2.0](http://www.mozilla.org/MPL/).
